// birth due date calculation

var birth_date;
function pregnancyCalculator() {
    var userDate = document.getElementById("duebirth_date").value;
    var periodcycle = document.getElementById("periodCycle").value;
    var dob = new Date(userDate);
    var date2 = new Date(userDate);
    if (userDate == null || userDate == "") {
      alert(" Date is required");
      return false;
    } else if (periodcycle == null || periodcycle == "") {
      alert(" period cycle is required is required");
      return false;
    } else {
      var diffTime = Math.abs(Date.now() - dob.getTime());
      var diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

      var duedays = Math.floor(diffDays % 7);
      var dueweeks = parseInt(diffDays / 7);

      //display the due date
      document.getElementById("fetalage").value =
        dueweeks + " Weeks " + duedays + " Days";
      // diffDays + " Week " + duedays + " Days";
      var newdate = dob.setDate(dob.getDate() + 280);
      document.getElementById("duedate").value = new Date(newdate);

      var conceptiondate = date2.setDate(date2.getDate() + parseInt(periodcycle));

      document.getElementById("conception").value = new Date(conceptiondate);
  }
}
