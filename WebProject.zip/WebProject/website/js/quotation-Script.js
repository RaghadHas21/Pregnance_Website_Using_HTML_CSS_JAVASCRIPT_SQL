var question = ["Are you in the first month of pregnancy?","Are you in the second month of pregnancy?","Are you in the third month of pregnancy?","Are you in the fouth month of pregnancy?","Are you in the five month of pregnancy?", "Are you in the six month of pregnancy?", "Are you in the seven month of pregnancy?","Are you in the eight month of pregnancy?","Are you in the ninth month of pregnancy?"]
var answer = ["You will be qualified for this stage, which will be one of the most exciting stages of your life. You are really strong and your child is lucky to have a mother like you","Remember, sweet mom: your baby has given you the greatest gift of your life !","“You will never understand life until it grows inside of you”","You will be qualified for this stage, which will be one of the most exciting stages of your life. You are really strong and your child is lucky to have a mother like you","Dear mom, You are pregnant and you are strong. You are bold and beautiful. Go forth in your boldness, beauty and satisfaction.","You will be qualified for this stage, which will be one of the most exciting stages of your life. You are really strong and your child is lucky to have a mother like you","The last trimester of pregnancy has begun, and the longing for your fetus has increased, to see it with your eyes and embrace it. This third will pass quickly and you will find hem next to you.","Being pregnant means every day is another day closer to meeting the other love of your life","Congratulation mommy it’s time to be the greatest and the most beautiful mother ever."]
var h3Question = document.querySelector(".Slide h3")
var pAns = document.querySelector(".Slide p")

var counter = 0;

document.getElementById("next").addEventListener("click",nextAction)
document.getElementById("prev").addEventListener("click",prevAction)

function nextAction(){
    console.log("check")
    counter++;
    if(counter == question.length){
        counter = 0;
    }
    h3Question.innerHTML = question[counter]
    pAns.innerHTML  = answer[counter]
}
function prevAction(){
    console.log("check")
    counter--;
    if(counter == -1){
        counter = question.length-1;
    }
    h3Question.innerHTML = question[counter]
    pAns.innerHTML  = answer[counter]


}