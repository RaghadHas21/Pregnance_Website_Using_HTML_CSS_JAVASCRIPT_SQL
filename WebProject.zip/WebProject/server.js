//Hello World Example
let msg = "Hi from server!";
console.log(msg);

//creating the server
const express = require("express"); //returns a function
const app = express();//calling the functions to 

//Serving static website
app.use("/", express.static("./website"));

//Handling POST request
// //establish database connection
// Include Express Validator Functions
const { check, validationResult } = require('express-validator');
// Validation Array
let formValidate = getFormValidation(); 
//setup an endpoint to receive messages sent to link
app.use(express.urlencoded({extended:false}))

app.post('/server',formValidate, (request,response)=>
{

  const errors = validationResult(request);
  if (!errors.isEmpty()) 
  {
  	// return response.json({ errors: errors.array() });
    let msg = "<h1>Sorry, we found errors with your submission.</h1>" + 
                printErrors(errors.array());
    response.send(msg)
  }

  else {
        //reading sent data
        const firstname = request.body.firstname;
        const lastname = request.body.lastname;
        const gender = request.body.gender;
        const email = request.body.email;
        const mobile = request.body.mobile;
        const birth_date = request.body.birth_date; 
        const language = request.body.language; 
        //adding user to DB
        addUser(firstname, lastname, gender, email, mobile, birth_date, language);   
        //sending back response
        let msg = "<h1>Thank you, your information has been saved. </h1>"; 
        response.send(msg);   
    }
});

//allow servet to listen to port
app.listen(2500, () => {
    console.log("server is listening on provided port");
});


function getFormValidation(){
    return [
            // Check fname
            check('firstname').isLength({min:1,max:100}).withMessage('First name must be between 1 and 100 chars in length')//length
                .isString().withMessage("First name must be of type string")//validate type
                .matches('[A-Za-z]+').withMessage("First name must consist of English letters only")//format
                .trim().escape(),//sanitize and clean
            // Check last name
            check('lastname').isLength({min:1,max:100}).withMessage('First name must be between 1 and 100 chars in length')//length
                .isString().withMessage("First name must be of type string")//validate type
                .matches('[A-Za-z]+').withMessage("First name must consist of English letters only")//format
                .trim().escape(),//sanitize and clean
            // Check last name
            check('lastname').isLength({min:1,max:100}).withMessage('First name must be between 1 and 100 chars in length')//length
                .isString().withMessage("First name must be of type string")//validate type
                .matches('[A-Za-z]+').withMessage("First name must consist of English letters only")//format
                .trim().escape(),//sanitize and clean
            //check email
            check('email').isLength({min:2,max:200}).withMessage('Email must be between 2 and 200 chars in length')//length
                .isString().withMessage("Email must be of type string")//validate type
                .isEmail().withMessage('Email must be in the correct email format e.g., x@y.com')//format
                .trim().escape(),//sanitize and clean
            //check mobile
            check('phone').isLength({min:10,max:10}).withMessage('Mobile must be exactly 10 digits')//length
                .isNumeric().withMessage('Mobile must consist of numbers only')//type
                .trim().escape(),//sanitize and clean
            //check radio selection
            check('gender').custom(val => {   
                    const whitelist = ['female', 'male'];
                    if(whitelist.includes(val)) return true
                    return false
                }).withMessage("Selection for 'gender' must be from provided list")
                .trim().escape()//sanitize and clean
        ];    
}

function printErrors(errArray){
    let errors = [];
    for (let index = 0; index < errArray.length; index++) {
        let err = errArray[index]["msg"];
        let msg = "<p>-"+err+"</p>";
        errors.push(msg);
    }
    return errors.join("");
}

function addUser(firstname, lastname, gender, email, mobile, birth_date, language){
    const mysql = require("mysql2");
    let db =  mysql.createConnection
    (
        {
            host: 'localhost',
            user: 'root',
            password: 'root',
            port: '3306',
            database: 'pregnant information'
        }
    );

    //connect to db
    db.connect(function(err) {
        //check for errors
        if (err) throw err;
        //create SQL command
        var sql = "INSERT INTO user (firstname, lastname, gender, birth_date, email, mobile, language) "+
        "VALUES ('"+firstname+"', '"+lastname+ "','"+gender+"','"+birth_date+"','"+email+"', '"+mobile+"', '"+language+"')";
        //execute SQL command
        db.query(sql, function (err, result) {
            //check for errors
          if (err) throw err;
          //if no errors, then successful
          console.log("1 record inserted");

          db.query('SELECT * FROM user',function(err,rows)
          {
            if(err) throw err;
            console.log('Data received');
            console.log(rows);
          });

        });
    });
}
